package it.utilityDB;

import java.util.ArrayList;

/**
 *
 * @author M2K
 */
public interface DBEntity {
    public boolean setByDB(ArrayList a);
}
